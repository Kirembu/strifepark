******************Welcome*******************

Welcome to the PHP Jquery Checkbox array Tutorial

1.  Edit the config.php file in the lib directory.
    Enter your MYSQL Username, Password and the name of your database.
    DB_SERVER is usually localhost!
    Please make sure there are no spaces as this will throw a error.


2.  Upload to your website and then use your web browser to find the setup file (setup.php)
    This could be http://localhost/jquery_checkboxes/lib/setup.php

3.  Click on setup and this will create your database and re-direct you to index.php in the root directory.


Any questions then contact me through my contact form on my blog http://www.worldoweb.co.uk/contact

